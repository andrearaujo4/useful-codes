
# this is a script to add to a single google ads account to get more visibility over any performance max campaigns running

If you've never used a script, don't worry it's just cut & paste. 
Here's a quick video to walk you through the process
https://www.loom.com/share/123920288d384e12b691c25ccfb1c951


You'll need to create a copy of the template spreadsheet (that's where all the work is done)
and then enter the URL of YOUR sheet at the top of the script
authorise it & run it.

Once it's all working, set it on a daily schedule. 

Celebrate... you're done!
